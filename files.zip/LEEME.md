# 🍰 Doré – Guía de Edición de la Web

## Archivos del proyecto
```
dore-web/
├── index.html   → Contenido y estructura
├── styles.css   → Estilos, colores, tipografía
└── app.js       → Interacciones y animaciones
```

---

## ✏️ QUÉ EDITAR EN index.html

Busca el texto `REEMPLAZA` en el archivo para encontrar todos los puntos de personalización:

### 🔗 Links de WhatsApp
Reemplaza `REEMPLAZA_LINK_WHATSAPP` con tu link real.
Ejemplo: `https://wa.me/573001234567?text=Hola,%20quiero%20pedir%20una%20Doré`

### 📸 Fotos / Imágenes
Reemplaza cada `<img src="https://images.unsplash.com/...">` con tus propias fotos.
Puedes usar rutas locales (`img/tarta.jpg`) si pones tus fotos en una carpeta `img/`.

### 💰 Precios
Busca `$<!-- PRECIO -->` y coloca tu precio real. Ej: `$35.000`

### 📋 Toppings y descripción de productos
Edita los párrafos `<p>` dentro de cada `.menu-card-body`

### ⭐ Testimonios
Reemplaza los textos de reseñas con reseñas reales de clientes.

### 📍 Datos de contacto (footer)
Reemplaza:
- `REEMPLAZA_LINK_INSTAGRAM` → tu link de Instagram
- `CIUDAD/ZONA DE COBERTURA` → tu ciudad o zona
- `HORARIO DE ATENCIÓN` → ej. Lun–Sáb 9am–7pm

### 🖼️ Logo
En la navbar hay: `<span class="logo-text">Doré</span>`
Si tienes logo en imagen, reemplaza por:
```html
<img src="img/logo.png" alt="Doré" style="height:50px;" />
```

---

## 🎨 QUÉ EDITAR EN styles.css

Al inicio del archivo están las variables de diseño:

```css
:root {
  --gold: #c8a96e;        /* Color dorado principal */
  --brown: #3d2b1f;       /* Color oscuro/café */
  --cream: #faf6f0;       /* Fondo crema */
  --gold-dark: #9c7c3e;   /* Dorado oscuro */
}
```

Cambia estos colores si quieres adaptar la paleta a tu marca.

---

## 📱 Cómo subir la web

**Opción 1 – Netlify (gratis, fácil):**
1. Ve a netlify.com
2. Arrastra la carpeta `dore-web/` al área de deploy
3. ¡Listo! Tienes URL en segundos

**Opción 2 – GitHub Pages (gratis):**
1. Crea un repositorio en github.com
2. Sube los archivos
3. Ve a Settings → Pages → Deploy from branch

---

## 💡 Tips de personalización rápida

- Cambia el número de WhatsApp en **TODOS** los botones (son varios)
- Usa fotos propias en buena resolución (mínimo 800px de ancho)
- Agrega las reseñas reales de tus clientes para mayor credibilidad
- Actualiza los precios con los valores actuales

---

Hecho con amor para Doré 🍰
